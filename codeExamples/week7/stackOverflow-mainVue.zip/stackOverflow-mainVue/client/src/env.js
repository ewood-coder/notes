export const dev = window.location.origin.includes('localhost')
export const baseURL = dev ? 'http://localhost:3000' : ''
export const useSockets = false
export const domain = 'dev-r74wuaxpejvz04an.us.auth0.com'
export const clientId = 'syO08A97sLrkuBY9Sl00CNYQxzR4XEPW'
export const audience = 'https://ewoodAPI.com'
